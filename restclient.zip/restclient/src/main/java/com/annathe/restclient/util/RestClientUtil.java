package com.annathe.restclient.util;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import com.annathe.restclient.model.Employee;

@Component
public class RestClientUtil {
	
	
	private RestTemplate template = new RestTemplate();
	
	
	public Employee getEmployee(int id) {
		
	  return template.getForObject("http://localhost:8087/employees/{id}", Employee.class, id);
		
		
		
	}

}
