package com.annathe.restclient.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.annathe.restclient.model.Employee;
import com.annathe.restclient.util.RestClientUtil;

@Controller
public class ClientController {	
	
	
	private RestTemplate template = new RestTemplate();
	

    @RequestMapping("/showForm")
    public String showForm(Model theModel)
    {
    	theModel.addAttribute("employee",new Employee());
    	
    	return "employee-form";
    }

	
	
	@RequestMapping("/getemployee")
	public String getEmployeeById( int id,Model theModel) {
			
		Employee emp = template.getForObject("http://localhost:8087/employees/{id}", Employee.class, id);
		
		theModel.addAttribute("employee", emp);
		
		return "update-form";
		
		
	}
	
	
	@RequestMapping("/processForm")
	public String processForm(@ModelAttribute("employee") Employee employee) {
		
		
		Employee emp = template.postForObject("http://localhost:8087/employees",employee, Employee.class);		
		
		
		
		return "employee-form";
	}

	@RequestMapping("/updateForm")
	public String updateForm(@ModelAttribute("employee") Employee employee) {
		
		
		 template.put("http://localhost:8087/employees/{id}",employee, employee.getId());		
		
		
		
		return "employee-form";
	}
	
	@RequestMapping("/getemployeefordelete")
	public String getEmployeeForDeleteById( int id,Model theModel) {
			
		Employee emp = template.getForObject("http://localhost:8087/employees/{id}", Employee.class, id);
		
		theModel.addAttribute("employee", emp);
		
		return "delete-form";
		
		
	}
	
	@RequestMapping("/deleteForm")
	public String deleteForm(@ModelAttribute("employee") Employee employee) {
		
		
		 template.delete("http://localhost:8087/employees/{id}", employee.getId());		
		
		
		
		return "employee-form";
	}

}
