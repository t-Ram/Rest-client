package com.annathe.restclient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.annathe.restclient.controller.ClientController;

@SpringBootApplication
public class RestclientApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestclientApplication.class, args);
		
		//ApplicationContext context = SpringApplication.run(RestclientApplication.class, args);

		//ClientController controller = context.getBean(ClientController.class); 
		
		//controller.getEmployeeById(1000);

	
	}

}
